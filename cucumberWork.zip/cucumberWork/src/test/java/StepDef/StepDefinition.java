package StepDef;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.runner.RunWith;

//@RunWith(Cucumber.class)
public class StepDefinition {
    @Given("^User wants to print name and surname$")
    public void user_wants_to_print_name_and_surname() throws Throwable {

    }

    @When("^Prompted to enter name and surname$")
    public void prompted_to_enter_name_and_surname() throws Throwable {

    }

    @Then("^Users name and surname gets printed$")
    public void users_name_and_surname_gets_printed() throws Throwable {

    }

}
